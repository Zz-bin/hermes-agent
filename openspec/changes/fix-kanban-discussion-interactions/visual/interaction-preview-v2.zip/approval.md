# 第二版待确认方案与设计稿

类型：请求批准；阶段：方案修订；builder → 用户。此版替代第一版的处理人位置与楼层跳转入口，补充评论图片粘贴方案；不是用户批准记录。第一版演示、附件11与历史交接仍保留，不是最新待确认稿。

## 最新反馈已纳入

- 当前处理人：详情左上，放在已有状态下拉框之前，右侧栏不重复可编辑入口。
- 楼层跳转：详情右侧悬浮目录，悬停短动画展开，支持点击与键盘；按原评论编号定位，排序/筛选不改编号。
- 图片粘贴：输入框主动粘贴截图后显示可移除缩略图；发表前不上传，失败保留文字和图片，成功后楼层内可查看。此行为仍待确认。

## 请你决定什么

1. 方案：是否接受新版，包括原附件预览/独立保存、底部常驻发表区、独立折叠、清晰边界，以及这次处理人位置、悬浮目录和图片粘贴？
2. 视觉稿：请打开下方第二版稿，确认左上处理人、右侧悬浮目录的悬停动画、底部图片缩略图和宽窄屏布局。所有数据和提交均为模拟；PDF位置与文件保存不等于真实产品验证。
3. 分配行为：更换正在工作的人时，你希望“停止当前处理并重新分配”，还是“不停当前工作，预约下一阶段的人”？当前推荐方案是前者并先确认；你的最新反馈只指定位置，还未决定这一行为。
4. 实现许可：确认方案与视觉后，是否允许在保留开发工作树实现上述范围？目前未授予，不能把恢复本卡或布局指示当实现批准。
5. 原第七项风扇问题：仍是性能调查候选。需要准确客户端主机/平台/安装版本、连接方式及后端版本，再做只读对照；真实根因与精确修复范围另确认，不捆绑全应用性能重构。

合并、部署、生产服务/当前聊天客户端重启、上游更新、push/PR、规格同步归档、旧工作树/备份清理均未授权。默认方案不自动执行HTML附件或启动系统默认程序。

## 可打开的材料

- 第二版交互稿：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/visual/interaction-v2.html
- 方案说明：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/design.md
- 范围提案：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/proposal.md
- 原始事实、用户指示、复用依据与未验证项：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/evidence/investigation.md
- 第二版行为结果：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/visual/v2-results.json
- 宽屏首屏：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/visual/v2-wide-entry.png
- 目录展开：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/visual/v2-toc-wide.png
- 390px窄屏图片+增高输入框：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/visual/v2-paste-narrow.png

卡片新版附件12为 kanban-interaction-demo-v2.zip；解压打开 interaction-v2.html。此附件只含可操作设计稿，不含方案和截图。完整方案、审批导航、调查摘要、截图与第二版结果的本地包：/home/capz/worktrees/hermes-kanban-detail/openspec/changes/fix-kanban-discussion-interactions/visual/interaction-preview-v2.zip 。均不含私密配置、凭据、数据库或编译缓存。附件11为第一版，不要以旧稿审第二版。完整包通过本地URL附卡被安全检查拒绝，未公开发布；设计稿改用正常文件附件上传并读回校验。

## 演示路径

1. 左上切换当前处理人；状态选择“处理中（模拟）”后再换人，可演示取消/明确确认。历史处理人保持只读。
2. 鼠标悬停详情右侧目录图标，点击楼层，或在目录输入编号定位；筛选builder后定位108，可取消或显示全部。排序后编号不变，跳转不替你选择上下文。
3. 在评论输入框粘贴截图；无法提供图片剪贴板时可点“示例截图”。图片可移除；勾选“模拟失败”后发表，草稿与图仍在；取消该选项再发，模拟新楼层显示图。全部只在本页，不上传。
4. 附件名称打开安全模拟预览，↓单独保存；展开、选中、再收起评论，检验操作互不干扰。增高输入框、缩窄到390px、滚至末尾，最后附件仍在发表区上方。

## 验证与限制

第二版通过真实Chrome点击/悬停/键盘与可见布局检查；具体逐项结果见v2-results.json。检查设计稿不代表产品已实现。图片粘贴采用合成剪贴板事件，未证明Mac/Windows系统截图粘贴；未验证真实上传、评论附件引用/认证预览、部分成功/超时恢复、真实分配或风扇因果。PDF与ZIP仍为明确模拟，不假造真实文件。原生基线调查与性能候选证据见investigation.md，旧证据不替代实际安装版本。

产品源码未改，HEAD仍为base。此次未启动服务器，正常验证浏览器已关闭；未运行产品全量测试。规格严格校验已通过。

## 下一步

待分配语义与方案确认后，builder补齐任务清单；只有明确实现许可才实现，再提交准确版本给reviewer。若要求预约下一阶段，先修订相关设计和规格再批准。不因本稿修改跳过审批或提前部署。

repo=/home/capz/.hermes/hermes-agent；worktree=/home/capz/worktrees/hermes-kanban-detail；branch=feature/kanban-detail-context；base/HEAD=6f515c4fc80e279f3078a90656eac21f53d5c57b；target=无实现提交；change=fix-kanban-discussion-interactions。
